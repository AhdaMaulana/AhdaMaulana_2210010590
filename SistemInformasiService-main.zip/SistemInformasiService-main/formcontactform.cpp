#include "formcontactform.h"
#include "ui_formcontactform.h"
#include "QMessageBox"

Formcontactform::Formcontactform(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Formcontactform)
{
    ui->setupUi(this);

    loadTableContactform();
}

Formcontactform::~Formcontactform()
{
    delete ui;
}

void Formcontactform::loadTableContactform()
{
    tabelModel = new QSqlQueryModel(this);
    tabelModel->setQuery("SELECT*FROM contact_form ORDER BY ID ASC");
    tabelModel->setHeaderData(0,Qt::Horizontal,QObject::tr("Nama Kontak"));
    tabelModel->setHeaderData(1,Qt::Horizontal,QObject::tr("Telp"));
    tabelModel->setHeaderData(2,Qt::Horizontal,QObject::tr("Pesan"));

    ui->tableContactform->setModel(tabelModel);
    ui->tableContactform->setColumnWidth(0,200);
    ui->tableContactform->setColumnWidth(1,100);
    ui->tableContactform->setColumnWidth(2,250);
    ui->tableContactform->show();
}

void Formcontactform::on_pushButton_clicked()
{
    if(ui->NameLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Nama Kontak Belum Di Isi");
        ui->NameLineEdit->setFocus();
    }else if(ui->IDLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "ID Belum Di Isi");
        ui->IDLineEdit->setFocus();
    }else if(ui->Phone_noLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Telp Type Belum Di Isi");
        ui->Phone_noLineEdit->setFocus();
    }else if(ui->MessageLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Pesan Price Belum Di Isi");
        ui->MessageLineEdit->setFocus();
    }else {
        QSqlQuery duplikat;
        duplikat.prepare("SELECT * FROM contact_form WHERE ID = '"+ui->IDLineEdit->text()+"'");
        duplikat.exec();
        if(duplikat.next()){
            QMessageBox::information(this, "warning", "ID sdh terdaftar");
            ui->NameLineEdit->setText(duplikat.value(1).toString());
            ui->Phone_noLineEdit->setText(duplikat.value(2).toString());
            ui->MessageLineEdit->setText(duplikat.value(3).toString());
        }else{
            QSqlQuery sql (koneksi);
            sql.prepare("INSERT INTO contact_form (Name,ID,Phone_no,Message)"
                        "VALUE (:Name,:ID,:Phone_no,:Message)");
            sql.bindValue(":Name",ui->NameLineEdit->text());
            sql.bindValue(":ID",ui->IDLineEdit->text());
            sql.bindValue(":Phone_no",ui->Phone_noLineEdit->text());
            sql.bindValue(":Message",ui->MessageLineEdit->text());

            if (sql.exec()){
                QMessageBox::information(this, "warning", "Data Berhasil Di simpan");
                ui->IDLineEdit->clear();
                ui->NameLineEdit->clear();
                ui->Phone_noLineEdit->clear();
                ui->MessageLineEdit->clear();
                loadTableContactform();
            }else{
                qDebug()<<sql.lastError().text();
            }
        }
    }
}


void Formcontactform::on_pushButton_2_clicked()
{
    QSqlQuery sql (koneksi);
    sql.prepare("UPDATE contact_form SET Name=:Name, Phone_no=:Phone_no, Message=:Message "
                " WHERE ID=:ID");
    sql.bindValue(":Name",ui->NameLineEdit->text());
    sql.bindValue(":ID",ui->IDLineEdit->text());
    sql.bindValue(":Phone_no",ui->Phone_noLineEdit->text());
    sql.bindValue(":Message",ui->MessageLineEdit->text());
    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Ubah";
        ui->IDLineEdit->clear();
        ui->NameLineEdit->clear();
        ui->Phone_noLineEdit->clear();
        ui->MessageLineEdit->clear();
        loadTableContactform();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void Formcontactform::on_pushButton_4_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM contact_form WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
        ui->IDLineEdit->clear();
        ui->NameLineEdit->clear();
        ui->Phone_noLineEdit->clear();
        ui->MessageLineEdit->clear();
        loadTableContactform();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void Formcontactform::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    QSqlRecord cari;
    sql.prepare("SELECT * FROM contact_form WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        QSqlRecord cari = sql.record();
        // ui->namaLineEdit->setText(cari.value());
        qDebug()<<cari.value(0).toString();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void Formcontactform::on_tableContactform_activated(const QModelIndex &index)
{
    int baris = ui->tableContactform->currentIndex().row();
    // QMessageBox::information(this, "warning", QString::number(baris));
    ui->NameLineEdit->setText(ui->tableContactform->model()->index(baris,0).data().toString());
    ui->IDLineEdit->setText(ui->tableContactform->model()->index(baris,1).data().toString());
    ui->Phone_noLineEdit->setText(ui->tableContactform->model()->index(baris,2).data().toString());
    ui->MessageLineEdit->setText(ui->tableContactform->model()->index(baris,3).data().toString());
}

