#ifndef FORMSERVICEUPLOAD_H
#define FORMSERVICEUPLOAD_H

#include <QWidget>
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlRecord>
#include <QSqlQueryModel>

namespace Ui {
class FormServiceupload;
}

class FormServiceupload : public QWidget
{
    Q_OBJECT

public:
    explicit FormServiceupload(QWidget *parent = nullptr);
    void loadTableServiceupload();
    ~FormServiceupload();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void on_tableServiceupload_activated(const QModelIndex &index);

private:
    Ui::FormServiceupload *ui;
    QSqlDatabase koneksi;
    QSqlQuery sql;
    QSqlRecord cari;
    QSqlQueryModel * tabelModel;
};

#endif // FORMSERVICEUPLOAD_H
