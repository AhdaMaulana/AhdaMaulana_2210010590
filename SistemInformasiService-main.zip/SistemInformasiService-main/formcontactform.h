#ifndef FORMCONTACTFORM_H
#define FORMCONTACTFORM_H

#include <QWidget>
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlRecord>
#include <QSqlQueryModel>

namespace Ui {
class Formcontactform;
}

class Formcontactform : public QWidget
{
    Q_OBJECT

public:
    explicit Formcontactform(QWidget *parent = nullptr);
    void loadTableContactform();
    ~Formcontactform();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void on_tableContactform_activated(const QModelIndex &index);

private:
    Ui::Formcontactform *ui;
    QSqlDatabase koneksi;
    QSqlQuery sql;
    QSqlRecord cari;
    QSqlQueryModel * tabelModel;
};

#endif // FORMCONTACTFORM_H
