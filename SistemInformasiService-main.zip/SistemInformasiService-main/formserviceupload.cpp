#include "formserviceupload.h"
#include "ui_formserviceupload.h"
#include "QMessageBox"

FormServiceupload::FormServiceupload(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormServiceupload)
{
    ui->setupUi(this);

    loadTableServiceupload();
}

FormServiceupload::~FormServiceupload()
{
    delete ui;
}

void FormServiceupload::loadTableServiceupload()
{
    tabelModel = new QSqlQueryModel(this);
    tabelModel->setQuery("SELECT*FROM service_upload ORDER BY ID ASC");
    tabelModel->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
    tabelModel->setHeaderData(1,Qt::Horizontal,QObject::tr("Nama Service"));
    tabelModel->setHeaderData(2,Qt::Horizontal,QObject::tr("Nama Service Type"));
    tabelModel->setHeaderData(3,Qt::Horizontal,QObject::tr("Laundry Price"));
    tabelModel->setHeaderData(4,Qt::Horizontal,QObject::tr("Dry Price"));

    ui->tableServiceupload->setModel(tabelModel);
    ui->tableServiceupload->setColumnWidth(0,100);
    ui->tableServiceupload->setColumnWidth(1,200);
    ui->tableServiceupload->setColumnWidth(2,200);
    ui->tableServiceupload->setColumnWidth(3,100);
    ui->tableServiceupload->setColumnWidth(4,100);
    ui->tableServiceupload->show();

    ui->service_typecomboBox->clear();
    ui->service_typecomboBox->addItem("");
    QSqlQueryModel *model = new QSqlQueryModel (ui->service_typecomboBox);
    model->setQuery ("SELECT service_name FROM service_type ORDER BY service_name ASC");
    ui->service_typecomboBox->setModel(model);
}

// void FormServicetype::indexChanged(int index)
// {
//     // QMessageBox::information(0, "", "Test");
//     // Do something here on ComboBox index change
//     QString value = ui->comboBox->currentText();
//     int id2;
//     if(!value.isEmpty())
//     {
//         id2 = value.toInt();
//     }
//     //Loading book table values to a table


//     QSqlQuery query  ;

//     // QString ids = QString("values('") + QString::number(id);
//     query.prepare(" SELECT*FROM service_type where ID = :id");
//     query.bindValue(":id",id2);
//     bool flag = query.exec();

//     //assigning the values to a QTableView
//     if(flag == true)
//     {

//         while(query.next())
//         {

//             ui->service_nameLineEdit->setText(query.value(1).toString());

//         }
//     }
//     else
//     {

//         QMessageBox :: critical(this,"Error",query.lastError().text());
//     }
// }

void FormServiceupload::on_pushButton_clicked()
{
    if(ui->IDLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "ID Belum Di Isi");
        ui->IDLineEdit->setFocus();
    }else if(ui->service_nameLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Nama Service Belum Di Isi");
        ui->service_nameLineEdit->setFocus();
    }else if(ui->service_typecomboBox->currentText().isEmpty()){
        QMessageBox::information(this, "warning", "Nama Service Type Belum Di Isi");
        ui->service_typecomboBox->setFocus();
    }else if(ui->laundry_priceLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Laundry Price Belum Di Isi");
        ui->laundry_priceLineEdit->setFocus();
    }else if(ui->dry_priceLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Dry Price Belum Di Isi");
        ui->dry_priceLineEdit->setFocus();
    }else {
        QSqlQuery duplikat;
        duplikat.prepare("SELECT * FROM admin_login WHERE ID = '"+ui->IDLineEdit->text()+"'");
        duplikat.exec();
        if(duplikat.next()){
            QMessageBox::information(this, "warning", "ID sdh terdaftar");
            ui->service_nameLineEdit->setText(duplikat.value(1).toString());
            ui->service_typecomboBox->setCurrentText(duplikat.value(2).toString());
            ui->laundry_priceLineEdit->setText(duplikat.value(3).toString());
            ui->dry_priceLineEdit->setText(duplikat.value(4).toString());
        }else{
            QSqlQuery sql (koneksi);
            sql.prepare("INSERT INTO service_upload (ID,service_name,service_type,laundry_price,dry_price)"
                        "VALUE (:ID,:service_name,:service_type,:laundry_price,:dry_price)");
            sql.bindValue(":ID",ui->IDLineEdit->text());
            sql.bindValue(":service_name",ui->service_nameLineEdit->text());
            sql.bindValue(":service_type",ui->service_typecomboBox->currentText());
            sql.bindValue(":laundry_price",ui->laundry_priceLineEdit->text());
            sql.bindValue(":dry_price",ui->dry_priceLineEdit->text());

            if (sql.exec()){
                QMessageBox::information(this, "warning", "Data Berhasil Di simpan");
                ui->IDLineEdit->clear();
                ui->service_nameLineEdit->clear();
                ui->service_typecomboBox->clear();
                ui->laundry_priceLineEdit->clear();
                ui->dry_priceLineEdit->clear();
                loadTableServiceupload();
            }else{
                qDebug()<<sql.lastError().text();
            }
        }
    }
}


void FormServiceupload::on_pushButton_2_clicked()
{
    QSqlQuery sql (koneksi);
    sql.prepare("UPDATE service_upload SET service_name=:service_name, service_type=:service_type, laundry_price=:laundry_price, "
                "dry_price=:dry_price WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());
    sql.bindValue(":service_name",ui->service_nameLineEdit->text());
    sql.bindValue(":service_type",ui->service_typecomboBox->currentText());
    sql.bindValue(":laundry_price",ui->laundry_priceLineEdit->text());
    sql.bindValue(":dry_price",ui->dry_priceLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Ubah";
        ui->IDLineEdit->clear();
        ui->service_nameLineEdit->clear();
        ui->service_typecomboBox->clear();
        ui->laundry_priceLineEdit->clear();
        ui->dry_priceLineEdit->clear();
        loadTableServiceupload();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormServiceupload::on_pushButton_4_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM service_upload WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
        ui->IDLineEdit->clear();
        ui->service_nameLineEdit->clear();
        ui->service_typecomboBox->clear();
        ui->laundry_priceLineEdit->clear();
        ui->dry_priceLineEdit->clear();
        loadTableServiceupload();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormServiceupload::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    QSqlRecord cari;
    sql.prepare("SELECT * FROM service_upload WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        QSqlRecord cari = sql.record();
        // ui->namaLineEdit->setText(cari.value());
        qDebug()<<cari.value(0).toString();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormServiceupload::on_tableServiceupload_activated(const QModelIndex &index)
{
    int baris = ui->tableServiceupload->currentIndex().row();
    // QMessageBox::information(this, "warning", QString::number(baris));
    ui->IDLineEdit->setText(ui->tableServiceupload->model()->index(baris,0).data().toString());
    ui->service_nameLineEdit->setText(ui->tableServiceupload->model()->index(baris,1).data().toString());
    ui->service_typecomboBox->setCurrentText(ui->tableServiceupload->model()->index(baris,2).data().toString());
    ui->laundry_priceLineEdit->setText(ui->tableServiceupload->model()->index(baris,3).data().toString());
    ui->dry_priceLineEdit->setText(ui->tableServiceupload->model()->index(baris,4).data().toString());
}

