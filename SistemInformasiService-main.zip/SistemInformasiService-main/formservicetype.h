#ifndef FORMSERVICETYPE_H
#define FORMSERVICETYPE_H

#include <QWidget>
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlRecord>
#include <QSqlQueryModel>

namespace Ui {
class FormServicetype;
}

class FormServicetype : public QWidget
{
    Q_OBJECT

public:
    explicit FormServicetype(QWidget *parent = nullptr);
    void loadTableServicetype();
    ~FormServicetype();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void indexChanged(int index);

    void on_tableServicetype_activated(const QModelIndex &index);

private:
    Ui::FormServicetype *ui;
    QSqlDatabase koneksi;
    QSqlQuery sql;
    QSqlRecord cari;
    QSqlQueryModel * tabelModel;
    QString selectionvalue;
};

#endif // FORMSERVICETYPE_H
