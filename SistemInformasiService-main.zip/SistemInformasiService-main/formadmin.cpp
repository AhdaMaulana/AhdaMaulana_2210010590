#include "formadmin.h"
#include "ui_formadmin.h"
#include "QMessageBox"

FormAdminlogin::FormAdminlogin(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormAdminlogin)
{
    ui->setupUi(this);

    loadTableAdminlogin();
}

FormAdminlogin::~FormAdminlogin()
{
    delete ui;
}

void FormAdminlogin::loadTableAdminlogin()
{
    tabelModel = new QSqlQueryModel(this);
    tabelModel->setQuery("SELECT*FROM admin_login ORDER BY ID ASC");
    tabelModel->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
    tabelModel->setHeaderData(1,Qt::Horizontal,QObject::tr("Nama"));
    tabelModel->setHeaderData(2,Qt::Horizontal,QObject::tr("Password"));

    ui->tableAdminlogin->setModel(tabelModel);
    ui->tableAdminlogin->setColumnWidth(0,100);
    ui->tableAdminlogin->setColumnWidth(1,100);
    ui->tableAdminlogin->show();
}

void FormAdminlogin::on_pushButton_clicked()
{
    if(ui->IDLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "ID Belum Di Isi");
        ui->IDLineEdit->setFocus();
    }else if(ui->adm_nameLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Nama Belum Di Isi");
        ui->adm_nameLineEdit->setFocus();
    }else if(ui->adm_passwordLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Password Belum Di Isi");
        ui->adm_passwordLineEdit->setFocus();
    }else {
        QSqlQuery duplikat;
        duplikat.prepare("SELECT * FROM admin_login WHERE ID = '"+ui->IDLineEdit->text()+"'");
        duplikat.exec();
        if(duplikat.next()){
            QMessageBox::information(this, "warning", "ID sdh terdaftar");
            ui->adm_nameLineEdit->setText(duplikat.value(1).toString());
            ui->adm_passwordLineEdit->setText(duplikat.value(2).toString());
        }else{
            QSqlQuery sql (koneksi);
            sql.prepare("INSERT INTO admin_login (ID,adm_name,adm_password)"
                        "VALUE (:ID,:adm_name,:adm_password)");
            sql.bindValue(":ID",ui->IDLineEdit->text());
            sql.bindValue(":adm_name",ui->adm_nameLineEdit->text());
            sql.bindValue(":adm_password",ui->adm_passwordLineEdit->text());

            if (sql.exec()){
                QMessageBox::information(this, "warning", "Data Berhasil Di simpan");
                ui->IDLineEdit->clear();
                ui->adm_nameLineEdit->clear();
                ui->adm_passwordLineEdit->clear();
                loadTableAdminlogin();
            }else{
                qDebug()<<sql.lastError().text();
            }
        }
    }
}


void FormAdminlogin::on_pushButton_2_clicked()
{
    QSqlQuery sql (koneksi);
    sql.prepare("UPDATE admin_login SET adm_name=:adm_name, adm_password=:adm_password WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());
    sql.bindValue(":adm_name",ui->adm_nameLineEdit->text());
    sql.bindValue(":adm_password",ui->adm_passwordLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Ubah";
        ui->IDLineEdit->clear();
        ui->adm_nameLineEdit->clear();
        ui->adm_passwordLineEdit->clear();
        loadTableAdminlogin();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormAdminlogin::on_pushButton_4_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM admin_login WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
        ui->IDLineEdit->clear();
        ui->adm_nameLineEdit->clear();
        ui->adm_passwordLineEdit->clear();
        loadTableAdminlogin();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormAdminlogin::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    QSqlRecord cari;
    sql.prepare("SELECT * FROM admin_login WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        QSqlRecord cari = sql.record();
        // ui->namaLineEdit->setText(cari.value());
        qDebug()<<cari.value(0).toString();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormAdminlogin::on_tableAdminlogin_activated(const QModelIndex &index)
{
    int baris = ui->tableAdminlogin->currentIndex().row();
    // QMessageBox::information(this, "warning", QString::number(baris));
    ui->IDLineEdit->setText(ui->tableAdminlogin->model()->index(baris,0).data().toString());
    ui->adm_nameLineEdit->setText(ui->tableAdminlogin->model()->index(baris,1).data().toString());
    ui->adm_passwordLineEdit->setText(ui->tableAdminlogin->model()->index(baris,2).data().toString());
}

