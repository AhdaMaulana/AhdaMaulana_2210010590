#include "formservicetype.h"
#include "ui_formservicetype.h"
#include "QMessageBox"
#include <QDebug>

FormServicetype::FormServicetype(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FormServicetype)
{
    ui->setupUi(this);

    QSqlDatabase koneksi = QSqlDatabase::addDatabase("QODBC");
    koneksi.setDatabaseName("ahdamaulana_2210010590");
    koneksi.setUserName("root");
    koneksi.setPassword("");

    if(!koneksi.open()){
        qDebug()<<koneksi.lastError().text();
    }else{
        qDebug()<<"Database Terkoneksi";

    }

    loadTableServicetype();
}

void FormServicetype::loadTableServicetype()
{
    tabelModel = new QSqlQueryModel(this);
    tabelModel->setQuery("SELECT*FROM service_type ORDER BY ID ASC");
    tabelModel->setHeaderData(0,Qt::Horizontal,QObject::tr("ID"));
    tabelModel->setHeaderData(1,Qt::Horizontal,QObject::tr("Nama Service Type"));

    ui->tableServicetype->setModel(tabelModel);
    ui->tableServicetype->setColumnWidth(0,100);
    ui->tableServicetype->setColumnWidth(1,250);
    ui->tableServicetype->show();

    // ui->comboBox->clear();
    // QSqlQueryModel *model = new QSqlQueryModel (ui->comboBox);
    // model->setQuery ("SELECT*FROM service_type ORDER BY ID ASC");
    // ui->comboBox->setModel(model);

    // connect(ui->comboBox, SIGNAL(currentIndexChanged(int)),
    //         this, SLOT(indexChanged(int)));
}

void FormServicetype::indexChanged(int index)
{
    // QMessageBox::information(0, "", "Test");
    // Do something here on ComboBox index change
    // QString value = ui->comboBox->currentText();
    // int id2;
    // if(!value.isEmpty())
    // {
    //     id2 = value.toInt();
    // }
    // //Loading book table values to a table


    // QSqlQuery query  ;

    // // QString ids = QString("values('") + QString::number(id);
    // query.prepare(" SELECT*FROM service_type where ID = :id");
    // query.bindValue(":id",id2);
    // bool flag = query.exec();

    // //assigning the values to a QTableView
    // if(flag == true)
    // {

    //     while(query.next())
    //     {

    //         ui->service_nameLineEdit->setText(query.value(1).toString());

    //     }
    // }
    // else
    // {

    //     QMessageBox :: critical(this,"Error",query.lastError().text());
    // }
}


FormServicetype::~FormServicetype()
{
    delete ui;
}

void FormServicetype::on_pushButton_clicked()
{
    if(ui->IDLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "ID Belum Di Isi");
        ui->IDLineEdit->setFocus();
    }else if(ui->service_nameLineEdit->text().isEmpty()){
        QMessageBox::information(this, "warning", "Nama Service Type Belum Di Isi");
        ui->service_nameLineEdit->setFocus();
    }else {
        QSqlQuery duplikat;
        duplikat.prepare("SELECT * FROM service_type WHERE ID = '"+ui->IDLineEdit->text()+"'");
        duplikat.exec();
        if(duplikat.next()){
            QMessageBox::information(this, "warning", "ID sdh terdaftar");
            ui->service_nameLineEdit->setText(duplikat.value(1).toString());
        }else{
            // koneksi.setSatuan(ui->satuanComboBox->currentText());

            QSqlQuery sql (koneksi);
            sql.prepare("INSERT INTO service_type (ID,service_name)"
                        "VALUE(:ID,:service_name)");
            sql.bindValue(":ID",ui->IDLineEdit->text());
            sql.bindValue(":service_name",ui->service_nameLineEdit->text());

            if (sql.exec()){
                QMessageBox::information(this, "warning", "Data Berhasil Di simpan");
                ui->IDLineEdit->clear();
                ui->service_nameLineEdit->clear();
                loadTableServicetype();
            }else{
                qDebug()<<sql.lastError().text();
            }
        }
    }
}


void FormServicetype::on_pushButton_2_clicked()
{
    QSqlQuery sql (koneksi);
    sql.prepare("UPDATE service_type SET service_name=:service_name WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());
    sql.bindValue(":service_name",ui->service_nameLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Ubah";
        ui->IDLineEdit->clear();
        ui->service_nameLineEdit->clear();
        loadTableServicetype();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormServicetype::on_pushButton_4_clicked()
{
    QSqlQuery sql(koneksi);
    sql.prepare("DELETE FROM service_type WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        qDebug()<<"Data Berhasil Di Hapus";
        ui->IDLineEdit->clear();
        ui->service_nameLineEdit->clear();
        loadTableServicetype();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormServicetype::on_pushButton_3_clicked()
{
    QSqlQuery sql(koneksi);
    QSqlRecord cari;
    sql.prepare("SELECT * FROM service_type WHERE ID=:ID");
    sql.bindValue(":ID",ui->IDLineEdit->text());

    if (sql.exec()){
        QSqlRecord cari = sql.record();
        // ui->namaLineEdit->setText(cari.value());
        qDebug()<<cari.value(0).toString();
    }else{
        qDebug()<<sql.lastError().text();
    }
}


void FormServicetype::on_tableServicetype_activated(const QModelIndex &index)
{
    int baris = ui->tableServicetype->currentIndex().row();
    // QMessageBox::information(this, "warning", QString::number(baris));
    ui->IDLineEdit->setText(ui->tableServicetype->model()->index(baris,0).data().toString());
    ui->service_nameLineEdit->setText(ui->tableServicetype->model()->index(baris,1).data().toString());
}
